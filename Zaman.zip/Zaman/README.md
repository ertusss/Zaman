# Zaman — Android uygulaması (Kotlin + Jetpack Compose)

Saat, kronometre (günlere ayrılmış geçmişle), yapılacaklar listesi (bildirimli hatırlatıcı) ve tema/arka plan ayarları.

## Özellikler

- **Saat:** analog + dijital saat, tarih, 24/12 saat biçimi, saniye göster/gizle
- **Kronometre:** başlat / duraklat / devam / tur / sıfırla. Sıfırlayınca süre **o günün altına** kaydedilir.
  Geçmiş gün gün gruplanır (günlük toplam süre, kayıt sayısı, dokununca turlar), tek tek silinebilir.
  Uygulamayı kapatsan da çalışan kronometre kaldığı yerden devam eder.
- **Yapılacaklar:** görev ekle / tamamla / sil. İstersen tarih + saat seçip **bildirimli hatırlatıcı** kurarsın.
  Telefon yeniden başlasa bile hatırlatıcılar tekrar kurulur.
- **Ayarlar:** tema modu (sistem/açık/koyu), 8 vurgu rengi, 6 arka plan, saat biçimi, ekran açık kalsın,
  izin durumları, 10 saniyelik test bildirimi, verileri temizleme.

## Derleme ve telefona kurma

1. **Android Studio** (Ladybug 2024.2 veya daha yenisi) ile `Zaman` klasörünü aç (`File > Open`).
2. Gradle senkronizasyonu bitsin (ilk seferde internet gerekir).
3. Oppo telefonda **Geliştirici seçenekleri > USB hata ayıklama**'yı aç
   (Ayarlar > Telefon hakkında > Sürüm numarasına 7 kez dokun).
4. Telefonu USB ile bağla, Android Studio'da üstteki cihaz listesinden seç ve **Run ▶** de.

Sadece APK istersen: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
Çıkan dosya `app/build/outputs/apk/debug/app-debug.apk`. Telefona kopyalayıp aç
(bilinmeyen kaynaklardan kuruluma izin vermen gerekebilir).

## Oppo (ColorOS) için önemli ayarlar

Oppo, arka plandaki uygulamaları agresif kapatır. Hatırlatıcıların uygulama kapalıyken gelmesi için:

- Ayarlar > Uygulamalar > Uygulama yönetimi > **Zaman** > Bildirimler: **açık**
- Aynı yerde **Otomatik başlatma** (veya "Arka planda çalışma"): **açık**
- Pil / Güç tasarrufu: **Kısıtlama yok** (veya "Arka planda çalışmaya izin ver")
- Android 12+ için: **Alarmlar ve hatırlatıcılar** iznini aç (uygulamadaki Ayarlar ekranından kısayol var)

Uygulamadaki **Ayarlar > "10 saniye sonra test bildirimi gönder"** ile, uygulamayı kapatıp
bildirimin gelip gelmediğini deneyebilirsin.

## Proje yapısı

```
app/src/main/java/com/cursed/zaman/
  MainActivity.kt, AppViewModel.kt
  data/      Models.kt, Storage.kt        (SharedPreferences + JSON)
  reminder/  ReminderScheduler.kt, ReminderReceiver.kt, BootReceiver.kt, NotificationHelper.kt
  ui/        App.kt, Theme.kt, ClockScreen.kt, StopwatchScreen.kt, TodoScreen.kt,
             SettingsScreen.kt, Components.kt, Fmt.kt
```

Renk paletlerini değiştirmek için `ui/Theme.kt` içindeki `AccentOptions` ve `BackgroundOptions` listelerine bak.
