package com.cursed.zaman.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cursed.zaman.AppViewModel
import com.cursed.zaman.data.Lap
import com.cursed.zaman.data.StopwatchSession
import com.cursed.zaman.data.StopwatchState
import kotlinx.coroutines.delay
import java.time.LocalDate

@Composable
fun StopwatchScreen(vm: AppViewModel) {
    val sw = vm.stopwatch

    // "Ekran açık kalsın" ayarı
    val view = LocalView.current
    val keepOn = vm.settings.keepScreenOnStopwatch && sw.running
    DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }

    val grouped: Map<LocalDate, List<StopwatchSession>> =
        vm.sessions.sortedByDescending { it.startedAt }.groupBy { it.startedAt.toLocalDate() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(key = "header") { StopwatchHeader(vm, sw) }

        if (sw.laps.isNotEmpty()) {
            item(key = "laps_title") {
                Text(
                    "Turlar",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(sw.laps, key = { "lap" + it.number }) { lap ->
                LapRow(lap)
            }
        }

        item(key = "history_title") {
            Text(
                "Geçmiş",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(top = 24.dp)
            )
        }

        if (grouped.isEmpty()) {
            item(key = "history_empty") {
                Text(
                    "Henüz kayıt yok. Kronometreyi durdurup \"Sıfırla\"ya bastığında süre, o günün altına kaydedilir.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        grouped.forEach { (date, list) ->
            item(key = "day_$date") { DayHeader(date, list) }
            items(list, key = { "s" + it.id }) { session ->
                SessionCard(session = session, onDelete = { vm.deleteSession(session.id) })
            }
        }
    }
}

@Composable
private fun StopwatchHeader(vm: AppViewModel, sw: StopwatchState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        StopwatchDisplay(sw)
        Spacer(Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (sw.running) {
                FilledTonalButton(
                    onClick = { vm.lap() },
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                ) {
                    Icon(Icons.Default.Flag, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Tur")
                }
            } else {
                FilledTonalButton(
                    onClick = { vm.resetStopwatch() },
                    enabled = sw.hasProgress,
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Sıfırla")
                }
            }

            Button(
                onClick = { if (sw.running) vm.pauseStopwatch() else vm.startStopwatch() },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
            ) {
                Icon(
                    if (sw.running) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = null
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    when {
                        sw.running -> "Duraklat"
                        sw.hasProgress -> "Devam"
                        else -> "Başlat"
                    }
                )
            }
        }
    }
}

/** Zamanlayıcıyı kendi içinde tutar; böylece tüm liste her karede yeniden çizilmez. */
@Composable
private fun StopwatchDisplay(sw: StopwatchState) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(sw.running) {
        if (sw.running) {
            while (true) {
                now = System.currentTimeMillis()
                delay(33)
            }
        } else {
            now = System.currentTimeMillis()
        }
    }

    Text(
        text = formatDuration(sw.elapsed(now)),
        style = MaterialTheme.typography.displayLarge.copy(fontFeatureSettings = "tnum"),
        fontSize = 56.sp,
        fontWeight = FontWeight.Light,
        maxLines = 1,
        softWrap = false
    )
}

@Composable
private fun LapRow(lap: Lap) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Tur " + lap.number,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f)
            )
            Text(
                formatDuration(lap.lapMillis),
                style = MaterialTheme.typography.bodyLarge.copy(fontFeatureSettings = "tnum"),
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.width(16.dp))
            Text(
                formatDuration(lap.totalMillis),
                style = MaterialTheme.typography.bodyMedium.copy(fontFeatureSettings = "tnum"),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
    }
}

@Composable
private fun DayHeader(date: LocalDate, list: List<StopwatchSession>) {
    val total = list.sumOf { it.durationMillis }
    Column(Modifier.padding(top = 12.dp)) {
        Text(
            dayTitle(date),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            list.size.toString() + " kayıt · toplam " + formatTotal(total),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SessionCard(session: StopwatchSession, onDelete: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Card(
        onClick = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        formatDuration(session.durationMillis),
                        style = MaterialTheme.typography.titleLarge.copy(fontFeatureSettings = "tnum")
                    )
                    val lapInfo = if (session.laps.isEmpty()) "tur yok" else session.laps.size.toString() + " tur"
                    Text(
                        formatClock(session.startedAt) + " başladı · " + lapInfo,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Default.Delete, contentDescription = "Sil")
                }
            }

            AnimatedVisibility(visible = expanded && session.laps.isNotEmpty()) {
                Column(Modifier.padding(end = 12.dp, top = 8.dp)) {
                    session.laps.sortedBy { it.number }.forEach { lap ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                        ) {
                            Text(
                                "Tur " + lap.number,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                formatDuration(lap.lapMillis),
                                style = MaterialTheme.typography.bodyMedium.copy(fontFeatureSettings = "tnum")
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Kaydı sil?") },
            text = { Text("Bu kronometre kaydı geçmişten kalıcı olarak silinecek.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete()
                }) { Text("Sil") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Vazgeç") }
            }
        )
    }
}
