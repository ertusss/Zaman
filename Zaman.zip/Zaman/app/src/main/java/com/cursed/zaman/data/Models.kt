package com.cursed.zaman.data

data class TodoItem(
    val id: Long,
    val title: String,
    val done: Boolean = false,
    /** Hatırlatma zamanı (epoch milisaniye). Yoksa null. */
    val remindAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class Lap(
    val number: Int,
    val lapMillis: Long,
    val totalMillis: Long
)

data class StopwatchSession(
    val id: Long,
    val startedAt: Long,
    val durationMillis: Long,
    /** En yeni tur başta. */
    val laps: List<Lap>
)

data class StopwatchState(
    val running: Boolean = false,
    /** Duraklatıldığında biriken süre. */
    val baseElapsed: Long = 0L,
    /** Son başlatma / devam etme anı (epoch milisaniye). */
    val resumedAtWall: Long = 0L,
    /** Oturumun ilk başladığı an. 0 = henüz başlamadı. */
    val sessionStartedAt: Long = 0L,
    /** En yeni tur başta. */
    val laps: List<Lap> = emptyList()
) {
    fun elapsed(now: Long): Long =
        if (running) baseElapsed + (now - resumedAtWall).coerceAtLeast(0L) else baseElapsed

    val hasProgress: Boolean get() = running || baseElapsed > 0L || laps.isNotEmpty()
}

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentIndex: Int = 0,
    val backgroundIndex: Int = 0,
    val use24h: Boolean = true,
    val showSeconds: Boolean = true,
    val keepScreenOnStopwatch: Boolean = false
)
