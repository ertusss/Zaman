package com.cursed.zaman.ui

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val TR: Locale = Locale.forLanguageTag("tr-TR")

fun Long.toLocalDate(): LocalDate =
    Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()

fun Long.toLocalDateTime(): LocalDateTime =
    Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDateTime()

/** 01:23.45  veya  1:02:03.45 */
fun formatDuration(ms: Long): String {
    val totalCs = (ms / 10).coerceAtLeast(0L)
    val cs = totalCs % 100
    val totalSec = totalCs / 100
    val s = totalSec % 60
    val m = (totalSec / 60) % 60
    val h = totalSec / 3600
    return if (h > 0) {
        String.format(Locale.ROOT, "%d:%02d:%02d.%02d", h, m, s, cs)
    } else {
        String.format(Locale.ROOT, "%02d:%02d.%02d", m, s, cs)
    }
}

/** Günlük toplam için okunabilir biçim: 1 sa 05 dk 12 sn */
fun formatTotal(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0L)
    val s = totalSec % 60
    val m = (totalSec / 60) % 60
    val h = totalSec / 3600
    return when {
        h > 0 -> String.format(Locale.ROOT, "%d sa %02d dk %02d sn", h, m, s)
        m > 0 -> String.format(Locale.ROOT, "%d dk %02d sn", m, s)
        else -> String.format(Locale.ROOT, "%d sn", s)
    }
}

fun dayTitle(date: LocalDate): String {
    val today = LocalDate.now()
    val full = date.format(DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE", TR))
    return when (date) {
        today -> "Bugün · $full"
        today.minusDays(1) -> "Dün · $full"
        else -> full
    }
}

fun formatClock(ms: Long): String =
    ms.toLocalDateTime().format(DateTimeFormatter.ofPattern("HH:mm", TR))

fun formatReminder(ms: Long): String {
    val dt = ms.toLocalDateTime()
    val today = LocalDate.now()
    val time = dt.format(DateTimeFormatter.ofPattern("HH:mm", TR))
    val day = when (dt.toLocalDate()) {
        today -> "Bugün"
        today.plusDays(1) -> "Yarın"
        else -> dt.format(DateTimeFormatter.ofPattern("d MMM", TR))
    }
    return "$day $time"
}
