package com.cursed.zaman.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.cursed.zaman.AppViewModel

private data class Tab(val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("Saat", Icons.Outlined.Schedule),
    Tab("Kronometre", Icons.Outlined.Timer),
    Tab("Yapılacaklar", Icons.Outlined.TaskAlt),
    Tab("Ayarlar", Icons.Outlined.Settings)
)

@Composable
fun ZamanApp(vm: AppViewModel) {
    ZamanTheme(vm.settings) {
        var tab by rememberSaveable { mutableIntStateOf(0) }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { index, t ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                Modifier
                    .padding(padding)
                    .fillMaxSize()
            ) {
                when (tab) {
                    0 -> ClockScreen(vm.settings)
                    1 -> StopwatchScreen(vm)
                    2 -> TodoScreen(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}
