package com.cursed.zaman.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.cursed.zaman.AppViewModel
import com.cursed.zaman.data.TodoItem
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val status = rememberPermissionStatus()

    var text by rememberSaveable { mutableStateOf("") }
    var remindAt by rememberSaveable { mutableStateOf<Long?>(null) }
    var showDate by remember { mutableStateOf(false) }
    var pickedDateMillis by remember { mutableStateOf<Long?>(null) }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* sonuç durumu ayrıca rememberPermissionStatus ile izleniyor */ }

    fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun submit() {
        if (text.isBlank()) return
        vm.addTodo(text, remindAt)
        text = ""
        remindAt = null
    }

    val active = vm.todos.filter { !it.done }
    val done = vm.todos.filter { it.done }

    val hasPendingReminder = remindAt != null ||
        vm.todos.any { !it.done && it.remindAt != null && it.remindAt > System.currentTimeMillis() }
    val permissionProblem = hasPendingReminder && (!status.notifications || !status.exactAlarms)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(key = "title") {
            Text("Yapılacaklar", style = MaterialTheme.typography.headlineMedium)
        }

        item(key = "input") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Yeni görev") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { submit() })
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AssistChip(
                            onClick = { showDate = true },
                            label = {
                                Text(remindAt?.let { formatReminder(it) } ?: "Hatırlatıcı ekle")
                            },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.Notifications,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        )
                        if (remindAt != null) {
                            IconButton(onClick = { remindAt = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Hatırlatıcıyı kaldır")
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        Button(onClick = { submit() }, enabled = text.isNotBlank()) {
                            Text("Ekle")
                        }
                    }
                }
            }
        }

        if (permissionProblem) {
            item(key = "permission_banner") {
                PermissionBanner(
                    notificationsOff = !status.notifications,
                    exactAlarmsOff = !status.exactAlarms,
                    onOpenNotifications = { openNotificationSettings(ctx) },
                    onOpenExactAlarms = { openExactAlarmSettings(ctx) }
                )
            }
        }

        if (vm.todos.isEmpty()) {
            item(key = "empty") {
                Text(
                    "Henüz görev yok. Yukarıdan bir görev ekle; istersen hatırlatıcı da kurabilirsin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        items(active, key = { "t" + it.id }) { todo ->
            TodoRow(
                todo = todo,
                onToggle = { vm.toggleTodo(todo.id) },
                onDelete = { vm.deleteTodo(todo.id) }
            )
        }

        if (done.isNotEmpty()) {
            item(key = "done_title") {
                Text(
                    "Tamamlananlar (" + done.size + ")",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }
            items(done, key = { "t" + it.id }) { todo ->
                TodoRow(
                    todo = todo,
                    onToggle = { vm.toggleTodo(todo.id) },
                    onDelete = { vm.deleteTodo(todo.id) }
                )
            }
        }
    }

    // 1) Tarih seç
    if (showDate) {
        val todayUtc = remember {
            LocalDate.now().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        }
        val dateState = rememberDatePickerState(
            initialSelectedDateMillis = todayUtc,
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long): Boolean = utcTimeMillis >= todayUtc
            }
        )
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton(onClick = {
                    pickedDateMillis = dateState.selectedDateMillis
                    showDate = false
                }) { Text("İleri") }
            },
            dismissButton = {
                TextButton(onClick = { showDate = false }) { Text("İptal") }
            }
        ) {
            DatePicker(state = dateState)
        }
    }

    // 2) Saat seç
    val picked = pickedDateMillis
    if (picked != null) {
        TimeDialog(
            onDismiss = { pickedDateMillis = null },
            onConfirm = { hour, minute ->
                val date = Instant.ofEpochMilli(picked).atZone(ZoneOffset.UTC).toLocalDate()
                val millis = LocalDateTime.of(date, LocalTime.of(hour, minute))
                    .atZone(ZoneId.systemDefault())
                    .toInstant()
                    .toEpochMilli()
                if (millis <= System.currentTimeMillis()) {
                    Toast.makeText(ctx, "Geçmiş bir zaman seçemezsin", Toast.LENGTH_SHORT).show()
                } else {
                    remindAt = millis
                    askNotificationPermission()
                }
                pickedDateMillis = null
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimeDialog(onDismiss: () -> Unit, onConfirm: (Int, Int) -> Unit) {
    val initial = remember { LocalTime.now().plusHours(1) }
    val state = rememberTimePickerState(
        initialHour = initial.hour,
        initialMinute = initial.minute,
        is24Hour = true
    )
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            tonalElevation = 6.dp,
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Saat seç",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier
                        .padding(bottom = 16.dp)
                        .align(Alignment.Start)
                )
                TimePicker(state = state)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("İptal") }
                    TextButton(onClick = { onConfirm(state.hour, state.minute) }) { Text("Tamam") }
                }
            }
        }
    }
}

@Composable
private fun PermissionBanner(
    notificationsOff: Boolean,
    exactAlarmsOff: Boolean,
    onOpenNotifications: () -> Unit,
    onOpenExactAlarms: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Hatırlatmalar eksik izinle çalışmayabilir", style = MaterialTheme.typography.titleSmall)
            }
            if (notificationsOff) {
                Text("Bildirimler kapalı; hatırlatma gelmez.", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = onOpenNotifications) { Text("Bildirim ayarlarını aç") }
            }
            if (exactAlarmsOff) {
                Text(
                    "\"Alarmlar ve hatırlatıcılar\" izni kapalı; hatırlatma birkaç dakika gecikebilir.",
                    style = MaterialTheme.typography.bodySmall
                )
                TextButton(onClick = onOpenExactAlarms) { Text("İzni aç") }
            }
        }
    }
}

@Composable
private fun TodoRow(todo: TodoItem, onToggle: () -> Unit, onDelete: () -> Unit) {
    val overdue = !todo.done && todo.remindAt != null && todo.remindAt <= System.currentTimeMillis()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Row(
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = todo.done, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(
                    todo.title,
                    style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (todo.done) TextDecoration.LineThrough else null,
                    color = if (todo.done) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface
                )
                if (todo.remindAt != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Notifications,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (overdue) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            formatReminder(todo.remindAt) + if (overdue) " · zamanı geçti" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (overdue) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Sil")
            }
        }
    }
}
