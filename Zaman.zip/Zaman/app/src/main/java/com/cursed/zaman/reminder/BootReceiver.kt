package com.cursed.zaman.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.cursed.zaman.data.Storage

/** Telefon yeniden başlayınca veya uygulama güncellenince alarmları yeniden kurar. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            ReminderScheduler.rescheduleAll(context, Storage(context).loadTodos())
        }
    }
}
