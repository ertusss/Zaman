package com.cursed.zaman.ui

import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cursed.zaman.AppViewModel
import com.cursed.zaman.data.ThemeMode
import com.cursed.zaman.reminder.ReminderScheduler

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings
    val ctx = LocalContext.current
    val status = rememberPermissionStatus()
    val dark = isDark(s.themeMode)

    var confirmHistory by remember { mutableStateOf(false) }
    var confirmDone by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            "Ayarlar",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(top = 8.dp)
        )

        // ---------- Görünüm ----------
        SectionTitle("Görünüm")

        Text("Tema modu", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.size(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                ThemeMode.SYSTEM to "Sistem",
                ThemeMode.LIGHT to "Açık",
                ThemeMode.DARK to "Koyu"
            ).forEach { (mode, label) ->
                FilterChip(
                    selected = s.themeMode == mode,
                    onClick = { vm.updateSettings { it.copy(themeMode = mode) } },
                    label = { Text(label) }
                )
            }
        }

        Spacer(Modifier.size(20.dp))
        Text("Vurgu rengi", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.size(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AccentOptions.forEachIndexed { index, option ->
                val selected = s.accentIndex == index
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(option.color)
                        .then(
                            if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onBackground, CircleShape)
                            else Modifier
                        )
                        .clickable { vm.updateSettings { it.copy(accentIndex = index) } },
                    contentAlignment = Alignment.Center
                ) {
                    if (selected) {
                        Icon(Icons.Default.Check, contentDescription = option.name, tint = Color.White)
                    }
                }
            }
        }

        Spacer(Modifier.size(20.dp))
        Text("Arka plan", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.size(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BackgroundOptions.forEachIndexed { index, option ->
                val selected = s.backgroundIndex == index
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(width = 72.dp, height = 52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(backgroundColorFor(option, dark))
                            .border(
                                border = if (selected) {
                                    BorderStroke(3.dp, MaterialTheme.colorScheme.primary)
                                } else {
                                    BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                                },
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { vm.updateSettings { it.copy(backgroundIndex = index) } },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = option.name,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Text(
                        option.name,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // ---------- Saat ----------
        SectionTitle("Saat")
        SettingSwitchRow(
            title = "24 saat biçimi",
            subtitle = "Kapalıysa 12 saat (ÖÖ/ÖS) gösterilir",
            checked = s.use24h,
            onChange = { v -> vm.updateSettings { it.copy(use24h = v) } }
        )
        SettingSwitchRow(
            title = "Saniyeyi göster",
            subtitle = "Dijital saatte ve akrepte saniye ibresi",
            checked = s.showSeconds,
            onChange = { v -> vm.updateSettings { it.copy(showSeconds = v) } }
        )

        // ---------- Kronometre ----------
        SectionTitle("Kronometre")
        SettingSwitchRow(
            title = "Çalışırken ekran açık kalsın",
            subtitle = "Kronometre çalışırken ekran kapanmaz",
            checked = s.keepScreenOnStopwatch,
            onChange = { v -> vm.updateSettings { it.copy(keepScreenOnStopwatch = v) } }
        )

        // ---------- Bildirimler ve izinler ----------
        SectionTitle("Bildirimler ve izinler")
        PermissionRow(
            title = "Bildirimler",
            ok = status.notifications,
            okText = "Açık",
            badText = "Kapalı — hatırlatma gelmez",
            actionLabel = "Aç",
            onAction = { openNotificationSettings(ctx) }
        )
        if (Build.VERSION.SDK_INT >= 31) {
            PermissionRow(
                title = "Alarmlar ve hatırlatıcılar",
                ok = status.exactAlarms,
                okText = "İzin verildi — tam zamanında çalar",
                badText = "Kapalı — hatırlatma gecikebilir",
                actionLabel = "Aç",
                onAction = { openExactAlarmSettings(ctx) }
            )
        }
        PermissionRow(
            title = "Pil optimizasyonu",
            ok = status.batteryUnrestricted,
            okText = "Kısıtlama yok",
            badText = "Uygulama kapalıyken bildirim gecikebilir",
            actionLabel = "Ayarla",
            onAction = { openBatterySettings(ctx) }
        )
        Text(
            "Oppo (ColorOS) telefonlarda ayrıca Ayarlar → Uygulamalar → Zaman içinden " +
                "\"Otomatik başlatma\" ve \"Arka planda çalışma\" izinlerini açman önerilir. " +
                "Menü adları ColorOS sürümüne göre biraz değişebilir.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp, bottom = 8.dp)
        )
        OutlinedButton(
            onClick = {
                ReminderScheduler.scheduleTest(ctx, 10)
                Toast.makeText(
                    ctx,
                    "10 saniye sonra test bildirimi gelecek. Uygulamayı kapatıp bekleyebilirsin.",
                    Toast.LENGTH_LONG
                ).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("10 saniye sonra test bildirimi gönder")
        }

        // ---------- Veri ----------
        SectionTitle("Veri")
        OutlinedButton(
            onClick = { confirmDone = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Tamamlanan görevleri sil") }
        Spacer(Modifier.size(8.dp))
        OutlinedButton(
            onClick = { confirmHistory = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Kronometre geçmişini temizle") }

        Spacer(Modifier.size(24.dp))
    }

    if (confirmDone) {
        AlertDialog(
            onDismissRequest = { confirmDone = false },
            title = { Text("Tamamlananlar silinsin mi?") },
            text = { Text("İşaretlenmiş tüm görevler kalıcı olarak silinecek.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDone = false
                    vm.clearCompletedTodos()
                }) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { confirmDone = false }) { Text("Vazgeç") } }
        )
    }

    if (confirmHistory) {
        AlertDialog(
            onDismissRequest = { confirmHistory = false },
            title = { Text("Geçmiş temizlensin mi?") },
            text = { Text("Tüm günlerdeki kronometre kayıtları kalıcı olarak silinecek.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmHistory = false
                    vm.clearSessions()
                }) { Text("Temizle") }
            },
            dismissButton = { TextButton(onClick = { confirmHistory = false }) { Text("Vazgeç") } }
        )
    }
}

@Composable
private fun PermissionRow(
    title: String,
    ok: Boolean,
    okText: String,
    badText: String,
    actionLabel: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (ok) Icons.Default.Check else Icons.Default.Warning,
            contentDescription = null,
            tint = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                if (ok) okText else badText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (!ok) {
            TextButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}
