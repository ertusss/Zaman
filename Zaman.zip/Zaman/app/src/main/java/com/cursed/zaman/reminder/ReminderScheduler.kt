package com.cursed.zaman.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.cursed.zaman.data.TodoItem

object ReminderScheduler {

    const val EXTRA_ID = "todo_id"
    const val EXTRA_TITLE = "todo_title"

    private const val TEST_ID = -1L

    private fun pending(context: Context, id: Long, title: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_TITLE, title)
        }
        return PendingIntent.getBroadcast(
            context,
            id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun alarmManager(context: Context): AlarmManager =
        context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canScheduleExact(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 31) alarmManager(context).canScheduleExactAlarms() else true

    fun schedule(context: Context, todo: TodoItem) {
        val at = todo.remindAt ?: return
        if (todo.done || at <= System.currentTimeMillis()) return

        val am = alarmManager(context)
        val pi = pending(context, todo.id, todo.title)

        try {
            if (canScheduleExact(context)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: SecurityException) {
            // İzin tam bu sırada geri alınmış olabilir; yaklaşık zamanlı alarma düş.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(context: Context, id: Long) {
        // PendingIntent eşleşmesi için extra'ların önemi yok; requestCode ve hedef sınıf yeterli.
        alarmManager(context).cancel(pending(context, id, ""))
    }

    fun rescheduleAll(context: Context, todos: List<TodoItem>) {
        todos.forEach { schedule(context, it) }
    }

    /** Uygulama kapalıyken bildirimin gelip gelmediğini denemek için. */
    fun scheduleTest(context: Context, afterSeconds: Int = 10) {
        schedule(
            context,
            TodoItem(
                id = TEST_ID,
                title = "Test: hatırlatıcılar çalışıyor ✅",
                remindAt = System.currentTimeMillis() + afterSeconds * 1000L
            )
        )
    }
}
