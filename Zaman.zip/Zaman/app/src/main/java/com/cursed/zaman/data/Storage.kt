package com.cursed.zaman.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Her şeyi SharedPreferences içinde (JSON olarak) saklar. Ek kütüphane gerekmez. */
class Storage(context: Context) {

    private val prefs =
        context.applicationContext.getSharedPreferences("zaman_prefs", Context.MODE_PRIVATE)

    // ---------- Ayarlar ----------

    fun loadSettings(): AppSettings {
        val mode = runCatching {
            ThemeMode.valueOf(prefs.getString("themeMode", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name)
        }.getOrDefault(ThemeMode.SYSTEM)
        return AppSettings(
            themeMode = mode,
            accentIndex = prefs.getInt("accentIndex", 0),
            backgroundIndex = prefs.getInt("backgroundIndex", 0),
            use24h = prefs.getBoolean("use24h", true),
            showSeconds = prefs.getBoolean("showSeconds", true),
            keepScreenOnStopwatch = prefs.getBoolean("keepScreenOn", false)
        )
    }

    fun saveSettings(s: AppSettings) {
        prefs.edit()
            .putString("themeMode", s.themeMode.name)
            .putInt("accentIndex", s.accentIndex)
            .putInt("backgroundIndex", s.backgroundIndex)
            .putBoolean("use24h", s.use24h)
            .putBoolean("showSeconds", s.showSeconds)
            .putBoolean("keepScreenOn", s.keepScreenOnStopwatch)
            .apply()
    }

    // ---------- Yapılacaklar ----------

    fun loadTodos(): List<TodoItem> {
        val raw = prefs.getString("todos", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                TodoItem(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    done = o.optBoolean("done", false),
                    remindAt = if (o.has("remindAt") && !o.isNull("remindAt")) o.getLong("remindAt") else null,
                    createdAt = o.optLong("createdAt", 0L)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveTodos(list: List<TodoItem>) {
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("title", t.title)
                    .put("done", t.done)
                    .put("remindAt", t.remindAt ?: JSONObject.NULL)
                    .put("createdAt", t.createdAt)
            )
        }
        prefs.edit().putString("todos", arr.toString()).apply()
    }

    // ---------- Kronometre geçmişi ----------

    fun loadSessions(): List<StopwatchSession> {
        val raw = prefs.getString("sessions", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                StopwatchSession(
                    id = o.getLong("id"),
                    startedAt = o.getLong("startedAt"),
                    durationMillis = o.getLong("duration"),
                    laps = lapsFromJson(o.optJSONArray("laps"))
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveSessions(list: List<StopwatchSession>) {
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(
                JSONObject()
                    .put("id", s.id)
                    .put("startedAt", s.startedAt)
                    .put("duration", s.durationMillis)
                    .put("laps", lapsToJson(s.laps))
            )
        }
        prefs.edit().putString("sessions", arr.toString()).apply()
    }

    // ---------- Çalışan kronometre ----------

    fun loadStopwatch(): StopwatchState {
        val raw = prefs.getString("stopwatch", null) ?: return StopwatchState()
        return runCatching {
            val o = JSONObject(raw)
            StopwatchState(
                running = o.optBoolean("running", false),
                baseElapsed = o.optLong("base", 0L),
                resumedAtWall = o.optLong("resumedAt", 0L),
                sessionStartedAt = o.optLong("startedAt", 0L),
                laps = lapsFromJson(o.optJSONArray("laps"))
            )
        }.getOrDefault(StopwatchState())
    }

    fun saveStopwatch(s: StopwatchState) {
        val o = JSONObject()
            .put("running", s.running)
            .put("base", s.baseElapsed)
            .put("resumedAt", s.resumedAtWall)
            .put("startedAt", s.sessionStartedAt)
            .put("laps", lapsToJson(s.laps))
        prefs.edit().putString("stopwatch", o.toString()).apply()
    }

    // ---------- Yardımcılar ----------

    private fun lapsToJson(laps: List<Lap>): JSONArray {
        val arr = JSONArray()
        laps.forEach {
            arr.put(JSONObject().put("n", it.number).put("lap", it.lapMillis).put("total", it.totalMillis))
        }
        return arr
    }

    private fun lapsFromJson(arr: JSONArray?): List<Lap> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Lap(o.getInt("n"), o.getLong("lap"), o.getLong("total"))
        }
    }
}
