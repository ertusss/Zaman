package com.cursed.zaman

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.cursed.zaman.data.AppSettings
import com.cursed.zaman.data.Lap
import com.cursed.zaman.data.StopwatchSession
import com.cursed.zaman.data.StopwatchState
import com.cursed.zaman.data.Storage
import com.cursed.zaman.data.TodoItem
import com.cursed.zaman.reminder.ReminderScheduler

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val app: Application = application
    private val storage = Storage(application)

    // ---------- Ayarlar ----------

    var settings by mutableStateOf(storage.loadSettings())
        private set

    fun updateSettings(block: (AppSettings) -> AppSettings) {
        settings = block(settings)
        storage.saveSettings(settings)
    }

    // ---------- Yapılacaklar ----------

    val todos = mutableStateListOf<TodoItem>().apply { addAll(storage.loadTodos()) }

    private fun persistTodos() = storage.saveTodos(todos.toList())

    fun addTodo(title: String, remindAt: Long?) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val item = TodoItem(id = System.currentTimeMillis(), title = clean, remindAt = remindAt)
        todos.add(0, item)
        persistTodos()
        ReminderScheduler.schedule(app, item)
    }

    fun toggleTodo(id: Long) {
        val i = todos.indexOfFirst { it.id == id }
        if (i < 0) return
        val updated = todos[i].copy(done = !todos[i].done)
        todos[i] = updated
        persistTodos()
        if (updated.done) ReminderScheduler.cancel(app, updated.id)
        else ReminderScheduler.schedule(app, updated)
    }

    fun deleteTodo(id: Long) {
        val i = todos.indexOfFirst { it.id == id }
        if (i < 0) return
        ReminderScheduler.cancel(app, id)
        todos.removeAt(i)
        persistTodos()
    }

    fun clearCompletedTodos() {
        todos.filter { it.done }.forEach { ReminderScheduler.cancel(app, it.id) }
        todos.removeAll { it.done }
        persistTodos()
    }

    // ---------- Kronometre ----------

    var stopwatch by mutableStateOf(storage.loadStopwatch())
        private set

    val sessions = mutableStateListOf<StopwatchSession>().apply { addAll(storage.loadSessions()) }

    private fun persistSessions() = storage.saveSessions(sessions.toList())

    private fun setStopwatch(state: StopwatchState) {
        stopwatch = state
        storage.saveStopwatch(state)
    }

    fun startStopwatch() {
        val sw = stopwatch
        if (sw.running) return
        val now = System.currentTimeMillis()
        setStopwatch(
            sw.copy(
                running = true,
                resumedAtWall = now,
                sessionStartedAt = if (sw.sessionStartedAt == 0L) now else sw.sessionStartedAt
            )
        )
    }

    fun pauseStopwatch() {
        val sw = stopwatch
        if (!sw.running) return
        setStopwatch(sw.copy(running = false, baseElapsed = sw.elapsed(System.currentTimeMillis())))
    }

    fun lap() {
        val sw = stopwatch
        if (!sw.running) return
        val total = sw.elapsed(System.currentTimeMillis())
        val previousTotal = sw.laps.firstOrNull()?.totalMillis ?: 0L
        val lap = Lap(number = sw.laps.size + 1, lapMillis = total - previousTotal, totalMillis = total)
        setStopwatch(sw.copy(laps = listOf(lap) + sw.laps))
    }

    /** Sıfırlarken süre kaydı o günün geçmişine eklenir. */
    fun resetStopwatch() {
        val sw = stopwatch
        val total = sw.elapsed(System.currentTimeMillis())
        if (total >= 10L && sw.sessionStartedAt > 0L) {
            sessions.add(
                0,
                StopwatchSession(
                    id = System.currentTimeMillis(),
                    startedAt = sw.sessionStartedAt,
                    durationMillis = total,
                    laps = sw.laps
                )
            )
            persistSessions()
        }
        setStopwatch(StopwatchState())
    }

    fun deleteSession(id: Long) {
        sessions.removeAll { it.id == id }
        persistSessions()
    }

    fun clearSessions() {
        sessions.clear()
        persistSessions()
    }
}
