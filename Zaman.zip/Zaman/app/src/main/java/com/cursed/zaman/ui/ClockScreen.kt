package com.cursed.zaman.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cursed.zaman.data.AppSettings
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ClockScreen(settings: AppSettings) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L - (now % 1000L) + 5L)
        }
    }

    val tr = remember { Locale.forLanguageTag("tr-TR") }
    val timeFmt = remember(settings.use24h, settings.showSeconds) {
        val pattern = buildString {
            append(if (settings.use24h) "HH:mm" else "hh:mm")
            if (settings.showSeconds) append(":ss")
        }
        SimpleDateFormat(pattern, tr)
    }
    val ampmFmt = remember { SimpleDateFormat("a", tr) }
    val dateFmt = remember { SimpleDateFormat("d MMMM yyyy", tr) }
    val dayFmt = remember { SimpleDateFormat("EEEE", tr) }

    val date = Date(now)
    val zone = TimeZone.getDefault()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AnalogClock(
            millis = now,
            showSeconds = settings.showSeconds,
            modifier = Modifier.size(260.dp)
        )

        Spacer(Modifier.height(32.dp))

        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = timeFmt.format(date),
                style = MaterialTheme.typography.displayLarge.copy(fontFeatureSettings = "tnum"),
                fontSize = 56.sp,
                fontWeight = FontWeight.Light,
                maxLines = 1,
                softWrap = false
            )
            if (!settings.use24h) {
                Text(
                    text = " " + ampmFmt.format(date),
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Text(
            text = dateFmt.format(date),
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Text(
            text = dayFmt.format(date),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(Modifier.height(16.dp))

        Text(
            text = zone.id + "  ·  " + zone.getDisplayName(zone.inDaylightTime(date), TimeZone.SHORT, tr),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun AnalogClock(millis: Long, showSeconds: Boolean, modifier: Modifier = Modifier) {
    val onBg = MaterialTheme.colorScheme.onBackground
    val accent = MaterialTheme.colorScheme.primary

    val cal = Calendar.getInstance().apply { timeInMillis = millis }
    val h = cal.get(Calendar.HOUR)
    val m = cal.get(Calendar.MINUTE)
    val s = cal.get(Calendar.SECOND)
    val hourAngle = (h + m / 60f) * 30f
    val minuteAngle = (m + s / 60f) * 6f
    val secondAngle = s * 6f

    Canvas(modifier = modifier) {
        val r = size.minDimension / 2f
        val c = center

        drawCircle(color = onBg.copy(alpha = 0.06f), radius = r)
        drawCircle(
            color = onBg.copy(alpha = 0.22f),
            radius = r - 1.5.dp.toPx(),
            style = Stroke(width = 3.dp.toPx())
        )

        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90.0)
            val major = i % 5 == 0
            val outer = r - 10.dp.toPx()
            val inner = outer - if (major) 12.dp.toPx() else 5.dp.toPx()
            drawLine(
                color = onBg.copy(alpha = if (major) 0.8f else 0.35f),
                start = Offset(c.x + cos(a).toFloat() * inner, c.y + sin(a).toFloat() * inner),
                end = Offset(c.x + cos(a).toFloat() * outer, c.y + sin(a).toFloat() * outer),
                strokeWidth = if (major) 3.dp.toPx() else 1.5.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        fun hand(angleDeg: Float, length: Float, width: Float, color: Color) {
            val a = Math.toRadians(angleDeg - 90.0)
            drawLine(
                color = color,
                start = c,
                end = Offset(c.x + cos(a).toFloat() * length, c.y + sin(a).toFloat() * length),
                strokeWidth = width,
                cap = StrokeCap.Round
            )
        }

        hand(hourAngle, r * 0.5f, 6.dp.toPx(), onBg)
        hand(minuteAngle, r * 0.75f, 4.dp.toPx(), onBg)
        if (showSeconds) hand(secondAngle, r * 0.85f, 2.dp.toPx(), accent)
        drawCircle(color = accent, radius = 6.dp.toPx(), center = c)
    }
}
