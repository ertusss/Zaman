package com.cursed.zaman.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.cursed.zaman.data.AppSettings
import com.cursed.zaman.data.ThemeMode

data class AccentOption(val name: String, val color: Color)

data class BackgroundOption(val name: String, val light: Color?, val dark: Color?)

val AccentOptions = listOf(
    AccentOption("Mor", Color(0xFF6750A4)),
    AccentOption("Mavi", Color(0xFF1E6FD9)),
    AccentOption("Turkuaz", Color(0xFF00897B)),
    AccentOption("Yeşil", Color(0xFF2E7D32)),
    AccentOption("Amber", Color(0xFFC77700)),
    AccentOption("Turuncu", Color(0xFFE65100)),
    AccentOption("Kırmızı", Color(0xFFD32F2F)),
    AccentOption("Pembe", Color(0xFFD81B60))
)

val BackgroundOptions = listOf(
    BackgroundOption("Varsayılan", null, null),
    BackgroundOption("Saf", Color(0xFFFFFFFF), Color(0xFF000000)),
    BackgroundOption("Krem", Color(0xFFFFF8E7), Color(0xFF2B2118)),
    BackgroundOption("Gökyüzü", Color(0xFFE8F1FF), Color(0xFF0D1B2A)),
    BackgroundOption("Nane", Color(0xFFE8F5E9), Color(0xFF10201A)),
    BackgroundOption("Gül", Color(0xFFFDEBF0), Color(0xFF2A1018))
)

fun backgroundColorFor(option: BackgroundOption, dark: Boolean): Color {
    val chosen = if (dark) option.dark else option.light
    return chosen ?: if (dark) Color(0xFF141218) else Color(0xFFFFFBFE)
}

@Composable
fun isDark(mode: ThemeMode): Boolean = when (mode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

private fun buildScheme(dark: Boolean, accent: Color, bgOption: BackgroundOption): ColorScheme {
    val bg = backgroundColorFor(bgOption, dark)
    return if (dark) {
        val onBg = Color(0xFFE6E1E5)
        darkColorScheme(
            primary = lerp(accent, Color.White, 0.35f),
            onPrimary = lerp(accent, Color.Black, 0.8f),
            primaryContainer = lerp(accent, Color.Black, 0.45f),
            onPrimaryContainer = lerp(accent, Color.White, 0.85f),
            secondary = lerp(accent, Color.White, 0.5f),
            onSecondary = lerp(accent, Color.Black, 0.8f),
            secondaryContainer = lerp(bg, accent, 0.30f),
            onSecondaryContainer = lerp(accent, Color.White, 0.85f),
            tertiary = lerp(accent, Color.White, 0.6f),
            background = bg,
            onBackground = onBg,
            surface = bg,
            onSurface = onBg,
            surfaceVariant = lerp(bg, onBg, 0.10f),
            onSurfaceVariant = lerp(onBg, bg, 0.25f),
            surfaceContainerLow = lerp(bg, accent, 0.06f),
            surfaceContainer = lerp(bg, accent, 0.10f),
            surfaceContainerHigh = lerp(bg, accent, 0.16f),
            outline = lerp(onBg, bg, 0.5f)
        )
    } else {
        val onBg = Color(0xFF1C1B1F)
        lightColorScheme(
            primary = lerp(accent, Color.Black, 0.12f),
            onPrimary = Color.White,
            primaryContainer = lerp(accent, bg, 0.80f),
            onPrimaryContainer = lerp(accent, Color.Black, 0.65f),
            secondary = lerp(accent, Color.Black, 0.2f),
            onSecondary = Color.White,
            secondaryContainer = lerp(bg, accent, 0.22f),
            onSecondaryContainer = lerp(accent, Color.Black, 0.6f),
            tertiary = lerp(accent, Color.Black, 0.3f),
            background = bg,
            onBackground = onBg,
            surface = bg,
            onSurface = onBg,
            surfaceVariant = lerp(bg, onBg, 0.08f),
            onSurfaceVariant = lerp(onBg, bg, 0.25f),
            surfaceContainerLow = lerp(bg, accent, 0.05f),
            surfaceContainer = lerp(bg, accent, 0.09f),
            surfaceContainerHigh = lerp(bg, accent, 0.14f),
            outline = lerp(onBg, bg, 0.5f)
        )
    }
}

@Composable
fun ZamanTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = isDark(settings.themeMode)
    val accent = AccentOptions.getOrElse(settings.accentIndex) { AccentOptions[0] }.color
    val bgOption = BackgroundOptions.getOrElse(settings.backgroundIndex) { BackgroundOptions[0] }
    val scheme = remember(dark, accent, bgOption) { buildScheme(dark, accent, bgOption) }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    MaterialTheme(colorScheme = scheme, content = content)
}
